chrome.runtime.onInstalled.addListener(() => {
  // 初始化扩展
});
